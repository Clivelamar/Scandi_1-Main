<?php

error_reporting( E_ALL );
ini_set( 'display_errors', 1 );

// create database table
include_once './db/database.php';

//  $DBConfig = new DatabaseConfig();

// if (!$DBConfig->create_table(true)) {
//     echo "An error occured while creating table";
// }

//echo $_GET['url'];

switch ($_GET['url']) {
    case 'index.php':
        include_once './views/product-list.php';
        break;

    case 'add-product':
        include_once './views/add-product.php';
        break;

    default:
        echo '<h1>Page does not exits</h1>';
        break;
}