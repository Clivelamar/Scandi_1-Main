<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once './models/product.php';
    $body = json_decode(file_get_contents('php://input'), true);

    $product = new Product();
    $product->sku = $body['sku'];
    $product->name = $body['name'];
    $product->price = $body['price'];
    $product->productType = $body['productType'];
    $product->size = $body['size'];
    $product->height = $body['height'];
    $product->width = $body['width'];
    $product->length = $body['length'];
    $product->weight = $body['weight'];

    $result = $product->save_product();

    if ($result == 'success') {
        echo json_encode(array('message' => 'Product created successfully'));
    } else {
        http_response_code(400);
        echo json_encode(array("error" => $result));
    }
    
    return;
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Add</title>
    <link rel="stylesheet" href="./css_js/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="wrapper container pt-4 pb-5">
        <form id="product_form" class="pb-3">
            <div class="form-header row align-items-center">
                <h1 class="col-sm-6">Product Add</h1>
                <div class="col-sm-6 text-end">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a href="/scandi_1-main" class="btn btn-secondary">Cancel</a>
                </div>
            </div>
            <hr />
            <div class="add-product-container">
                <div class="alert alert-danger text-center" role="alert" id="alert-box"></div>
                <div class="mb-3 row">
                    <label for="sku" class="col-sm-2 col-form-label">SKU</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="sku">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="name" class="col-sm-2 col-form-label">Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="name">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="price" class="col-sm-2 col-form-label">Price ($)</label>
                    <div class="col-sm-10">
                        <input type="number" min="0" class="form-control" id="price">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="productType" class="col-sm-2 col-form-label">Type Switcher </label>
                    <div class="col-sm-10">
                        <select id="productType" class="form-select">
                            <option value="" selected>Type switcher</option>
                            <option value="DVD">DVD</option>
                            <option value="Book">Book</option>
                            <option value="Furniture">Furniture</option>
                        </select>
                    </div>
                </div>
                <div id="DVD" class="type-specific">
                    <div class="mb-3 row">
                        <label for="size" class="col-sm-2 col-form-label">Size (MB)</label>
                        <div class="col-sm-10">
                            <input type="number" min="0" class="form-control" id="size">
                        </div>
                        <small class="col-12 text-secondary">Please, provide DVD size</small>
                    </div>
                </div>
                <div id="Furniture" class="type-specific">
                    <div class="mb-3 row">
                        <label for="height" class="col-sm-2 col-form-label">Height (CM)</label>
                        <div class="col-sm-10">
                            <input type="number" min="0" class="form-control" id="height">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="width" class="col-sm-2 col-form-label">Width (CM)</label>
                        <div class="col-sm-10">
                            <input type="number" min="0" class="form-control" id="width">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="length" class="col-sm-2 col-form-label">Length (CM)</label>
                        <div class="col-sm-10">
                            <input type="number" min="0" class="form-control" id="length">
                        </div>
                    </div>
                    <small class="col-12 text-secondary">Please, provide Furniture dimensions</small>
                </div>
                <div id="Book" class="type-specific">
                    <div class="mb-3 row">
                        <label for="weight" class="col-sm-2 col-form-label">Weight (KG)</label>
                        <div class="col-sm-10">
                            <input type="number" min="0" class="form-control" id="weight">
                        </div>
                        <small class="col-12 text-secondary">Please, provide Book weight</small>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <?php require_once 'footer.php' ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
</body>
<script src="./css_js/script.js"></script>

</html>