<?php
require_once './models/product.php';
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $product = new Product;
    $body = json_decode(file_get_contents('php://input'), true);

    $result = $product->buik_delete($body);

    if ($result == 'success') {
        echo json_encode(array('message' => 'Products Deleted successfully'));
    } else {
        http_response_code(400);
        echo json_encode(array("error" => $result));
    }
    
    return;
}

$product = new Product;
$products = $product->all();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link rel="stylesheet" href="./css_js/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="wrapper container pt-4 pb-5">
        <div class="pb-3">
            <div class="form-header row align-items-center">
                <h1 class="col-sm-6">Product List</h1>
                <div class="buttons col-sm-6 text-end">
                    <a class="btn btn-primary" href="./add-product">ADD</a>
                    <button class="btn btn-danger" type="button" id="delete-product-btn">MASS DELETE</button>
                </div>
            </div>
            <hr />
            <div class="products-container">
                <div class="row justify-content-center">
                    <?php
                    foreach ($products as $key => $prod) {
                        ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="product-card card mb-2">
                                <div class="card-header bg-white">
                                    <input class="form-check-input border border-primary delete-checkbox" type="checkbox"
                                        value="<?= $prod->sku ?>">
                                </div>
                                <div class="card-body text-center">
                                    <p class="card-text">
                                        <?= $prod->sku ?>
                                    </p>
                                    <p class="card-text">
                                        <?= $prod->name ?>
                                    </p>
                                    <p class="card-text">
                                        <?= $prod->price ?> $
                                    </p>
                                    <?php
                                    switch ($prod->productType) {
                                        case 'Book':
                                            echo 'Weight: ' . $prod->weight . ' KG';
                                            break;

                                        case 'DVD':
                                            echo 'Size: ' . $prod->size . ' MB';
                                            break;

                                        case 'Furniture':
                                            echo 'Dimension: ' . $prod->height . ' x ' . $prod->width . ' x ' . $prod->length;
                                            break;

                                        default:
                                            break;
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
    <?php require_once 'footer.php' ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"
        integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
</body>
<script>
    $(document).ready(() => {
        let productSKUs = [];

        const productCheckbox = $('.delete-checkbox');
        productCheckbox.on('change', (e) => {
            if (e.target.checked) {
                productSKUs.push(e.target.value);
            } else {
                productSKUs = productSKUs.filter((sku) => sku != e.target.value)
            }
        })

        $('#delete-product-btn').on('click', () => {
            if (productCheckbox.length == 0) {
                return
            }

            $.ajax({
                method: 'DELETE',
                url: '/scandi_1-main',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(productSKUs),
                dataType: 'json',
                success: function (res) {
                    window.location.href = "/scandi_1-main"
                },
                error: function (XMLHttpRequest) {
                    alertBox.html(XMLHttpRequest.responseJSON.error);
                    alertBox.show()
                }
            })
        })
    })
</script>

</html>